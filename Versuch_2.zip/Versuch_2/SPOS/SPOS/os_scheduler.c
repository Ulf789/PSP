/*! \file
 *  \brief Scheduling module for the OS.
 *
 * Contains everything needed to realise the scheduling between multiple processes.
 * Also contains functions to start the execution of programs.
 *
 *  \author   Lehrstuhl Informatik 11 - RWTH Aachen
 *  \date     2013
 *  \version  2.0
 */

#include "os_scheduler.h"
#include "util.h"
#include "os_input.h"
#include "os_scheduling_strategies.h"
#include "os_taskman.h"
#include "os_core.h"
#include "lcd.h"

#include <avr/interrupt.h>
#include <stdbool.h>

//----------------------------------------------------------------------------
// Private Types
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Globals
//----------------------------------------------------------------------------

//! Array of states for every possible process
//#warning IMPLEMENT STH. HERE
Process os_processes[MAX_NUMBER_OF_PROCESSES];

//! Index of process that is currently executed (default: idle)
//#warning IMPLEMENT STH. HERE
ProcessID currentProc;

//----------------------------------------------------------------------------
// Private variables
//----------------------------------------------------------------------------

//! Currently active scheduling strategy
//#warning IMPLEMENT STH. HERE
SchedulingStrategy currentStr;

//! Count of currently nested critical sections
//#warning IMPLEMENT STH. HERE
uint16_t criticalSectionCount = 0;

//----------------------------------------------------------------------------
// Private function declarations
//----------------------------------------------------------------------------

//! ISR for timer compare match (scheduler)
ISR(TIMER2_COMPA_vect) __attribute__((naked));

//----------------------------------------------------------------------------
// Function definitions
//----------------------------------------------------------------------------

/*!
 *  Timer interrupt that implements our scheduler. Execution of the running
 *  process is suspended and the context saved to the stack. Then the periphery
 *  is scanned for any input events. If everything is in order, the next process
 *  for execution is derived with an exchangeable strategy. Finally the
 *  scheduler restores the next process for execution and releases control over
 *  the processor to that process.
 */
ISR(TIMER2_COMPA_vect) {
    //#warning IMPLEMENT STH. HERE
	saveContext();
	os_processes[os_getCurrentProc()].sp.as_int = SP; 
	SP = BOTTOM_OF_ISR_STACK;
	os_processes[os_getCurrentProc()].checksum = os_getStackChecksum(os_getCurrentProc());
	if(os_getInput() == 0b00001001) {
		os_waitForNoInput();
		os_taskManMain();
	}
	os_processes[os_getCurrentProc()].state = OS_PS_READY;
	if (os_getSchedulingStrategy() == OS_SS_EVEN){
		currentProc = os_Scheduler_Even(os_processes,os_getCurrentProc());
	}
	if (os_getSchedulingStrategy() == OS_SS_RANDOM){
		currentProc = os_Scheduler_Random(os_processes,os_getCurrentProc());
	}
	os_processes[os_getCurrentProc()].state = OS_PS_RUNNING;
	if (os_processes[currentProc].checksum != os_getStackChecksum(currentProc)) {
		os_error("INKONSISTENZ");
	}
	SP = os_processes[os_getCurrentProc()].sp.as_int;
	restoreContext();
}

/*!
 *  This is the idle program. The idle process owns all the memory
 *  and processor time no other process wants to have.
 */
void idle(void) {
    //#warning IMPLEMENT STH. HERE
	while (1){
		lcd_writeString(PSTR("...."));
		//delayMs(DEFAULT_OUTPUT_DELAY);
	}	
}

/*!
 *  This function is used to execute a program that has been introduced with
 *  os_registerProgram.
 *  A stack will be provided if the process limit has not yet been reached.
 *  This function is multitasking safe. That means that programs can repost
 *  themselves, simulating TinyOS 2 scheduling (just kick off interrupts ;) ).
 *
 *  \param program  The function of the program to start.
 *  \param priority A priority ranging 0..255 for the new process:
 *                   - 0 means least favourable
 *                   - 255 means most favourable
 *                  Note that the priority may be ignored by certain scheduling
 *                  strategies.
 *  \return The index of the new process or INVALID_PROCESS as specified in
 *          defines.h on failure
 */
ProcessID os_exec(Program *program, Priority priority) {
    //#warning IMPLEMENT STH. HERE
	os_enterCriticalSection();
	uint8_t flag = 0;
	ProcessID pid=0;
	
	for (uint8_t i=0; i < MAX_NUMBER_OF_PROCESSES ; i++){
		if (os_processes[i].state == OS_PS_UNUSED){
			flag = 1;
			pid = i;
			break;
		}
	}
	
	if (flag ==0){
		os_leaveCriticalSection();
		return INVALID_PROCESS;
	}
	
	if (program == NULL){
		os_leaveCriticalSection();
		return INVALID_PROCESS;
	}
	Process* newPtr = &os_processes[pid];
	newPtr->state = OS_PS_READY;
	newPtr->program = program;
	newPtr->priority = priority;
	newPtr->sp.as_int = PROCESS_STACK_BOTTOM(pid);
	
	uint16_t lowbyte = ((uint16_t)newPtr->program) & 0x00ff;
	uint16_t highbyte = ((uint16_t)newPtr->program) >> 8;
	
	*(newPtr->sp.as_ptr)=lowbyte;
	newPtr->sp.as_ptr--;
	*(newPtr->sp.as_ptr)=highbyte;
	newPtr->sp.as_ptr--;
	
	for (uint8_t b=0; b<33; b++){
		*(newPtr->sp.as_ptr)=0;
		newPtr->sp.as_ptr--;
	}
	newPtr->checksum = os_getStackChecksum(pid);
	os_leaveCriticalSection();
	return pid;
}

/*!
 *  If all processes have been registered for execution, the OS calls this
 *  function to start the idle program and the concurrent execution of the
 *  applications.
 */
void os_startScheduler(void) {
    //#warning IMPLEMENT STH. HERE
	currentProc=0;
	os_processes[0].state = OS_PS_RUNNING;
	SP = os_processes[0].sp.as_int;
	restoreContext();
}

/*!
 *  In order for the Scheduler to work properly, it must have the chance to
 *  initialize its internal data-structures and register.
 */
void os_initScheduler(void) {
	//#warning IMPLEMENT STH. HERE
	for (uint8_t i=0; i<MAX_NUMBER_OF_PROCESSES; i++){
		os_processes[i].state = OS_PS_UNUSED;
	}
	os_exec(idle,DEFAULT_PRIORITY);
	while (autostart_head != NULL) {
		os_exec(autostart_head->program,DEFAULT_PRIORITY);
		autostart_head = autostart_head->next;
	}
}

/*!
 *  A simple getter for the slot of a specific process.
 *
 *  \param pid The processID of the process to be handled
 *  \return A pointer to the memory of the process at position pid in the os_processes array.
 */
Process* os_getProcessSlot(ProcessID pid) {
    return os_processes + pid;
}

/*!
 *  A simple getter to retrieve the currently active process.
 *
 *  \return The process id of the currently active process.
 */
ProcessID os_getCurrentProc(void) {
    //#warning IMPLEMENT STH. HERE
	return currentProc;
}

/*!
 *  Sets the current scheduling strategy.
 *
 *  \param strategy The strategy that will be used after the function finishes.
 */
void os_setSchedulingStrategy(SchedulingStrategy strategy) {
    //#warning IMPLEMENT STH. HERE
	currentStr = strategy;
}

/*!
 *  This is a getter for retrieving the current scheduling strategy.
 *
 *  \return The current scheduling strategy.
 */
SchedulingStrategy os_getSchedulingStrategy(void) {
    //#warning IMPLEMENT STH. HERE
	return currentStr;
}

/*!
 *  Enters a critical code section by disabling the scheduler if needed.
 *  This function stores the nesting depth of critical sections of the current
 *  process (e.g. if a function with a critical section is called from another
 *  critical section) to ensure correct behaviour when leaving the section.
 *  This function supports up to 255 nested critical sections.
 */
void os_enterCriticalSection(void) {
    //#warning IMPLEMENT STH. HERE
	if(criticalSectionCount >= 255){
		os_error("leave-> enterCritSection error");
		return;
	}
	uint8_t GIEBL = SREG & 0b10000000;
	SREG &= 0b01111111;
	criticalSectionCount++;
	TIMSK2 &= 0b11111101;
	SREG |= GIEBL;
}

/*!
 *  Leaves a critical code section by enabling the scheduler if needed.
 *  This function utilizes the nesting depth of critical sections
 *  stored by os_enterCriticalSection to check if the scheduler
 *  has to be reactivated.
 */
void os_leaveCriticalSection(void) {
    //#warning IMPLEMENT STH. HERE
	if(criticalSectionCount <= 0){
		os_error("leave-> enterCritSection error");
		return;
	}
	uint8_t GIEBL = SREG & 0b10000000;
	SREG &= 0b01111111;
	criticalSectionCount--;
	if (criticalSectionCount == 0){
		TIMSK2 |= 0b00000010;
	}
	SREG |= GIEBL;
}


/*!
 *  Calculates the checksum of the stack for a certain process.
 *
 *  \param pid The ID of the process for which the stack's checksum has to be calculated.
 *  \return The checksum of the pid'th stack.
 */
StackChecksum os_getStackChecksum(ProcessID pid) {
    //#warning IMPLEMENT STH. HERE
	 StackPointer stackptr =  os_processes[pid].sp;
	 StackPointer anfang;
	 anfang.as_int = PROCESS_STACK_BOTTOM(pid);
	 StackChecksum checksum = *(anfang.as_ptr);
	 while(stackptr.as_int < anfang.as_int-1){
		 anfang.as_int--;
		 checksum ^= *(anfang.as_ptr);
	 }
	 return checksum;
}
