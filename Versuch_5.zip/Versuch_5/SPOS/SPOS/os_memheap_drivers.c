#include "os_memheap_drivers.h"
#include "defines.h"
#include "os_memory_strategies.h"
#include <avr/pgmspace.h>

char intStr[] = "internal";
char extStr[] = "external";


Heap intHeap__ = {
	.driver = intSRAM,
	.mapStart = HEAPBOTTOM,
	.mapSize = MAP_SIZE,
	.useStart = HEAPBOTTOM + MAP_SIZE,
	.useSize = MAP_SIZE+MAP_SIZE,
	.currentAllocStrategy = OS_MEM_FIRST,
	.name = intStr,
	.nextStart = HEAPBOTTOM + MAP_SIZE
};

Heap extHeap__ = {
	.driver = extSRAM,
	.mapStart = 0,
	.mapSize = 21845,
	.useStart = 21845,
	.useSize = 43690,
	.currentAllocStrategy = OS_MEM_FIRST,
	.name = extStr,
	.nextStart = 21845
};

void os_initHeaps(){
	for (uint16_t i=0;i<intHeap__.mapSize;i++){
		intHeap__.driver->write(intHeap__.mapStart+i, 0);
	}
	for (uint16_t i=0;i<extHeap__.mapSize;i++){
		extHeap__.driver->write(extHeap__.mapStart+i, 0);
	}
	for (uint8_t i = 1; i < MAX_NUMBER_OF_PROCESSES; i++)
	{
		intHeap__.allocFrameStart[i] = 0;
		intHeap__.allocFrameEnd[i] = 0;
		extHeap__.allocFrameStart[i] = 0;
		extHeap__.allocFrameEnd[i] = 0;
	}
}

size_t os_getHeapListLength (void){
	return 2;
}

Heap *os_lookupHeap (uint8_t index){
	if (index == 1){
		return extHeap;
	}else return intHeap;
}