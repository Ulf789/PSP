#include "os_spi.h"
#include "os_scheduler.h"



void os_spi_init (void){
	DDRB |= 0b10111000;
	DDRB &= 0b10111111;
	PORTB |= 0b00010000;
	
	SPCR = 0b01010000;
	/*SPCR |= 0b01010000;//Master aktiv
	SPCR &= 0b01010011;//CP0L CPHA 0 DORD 0 SPIE 0
	SPCR &= 0b11111100;//SPR1 PSR0 0*/
	SPSR |= 0b00000001;//SPI2X 1
	
}

uint8_t os_spi_send (uint8_t data){
	SPDR = data;
	while ((SPSR & 0b10000000) !=0b10000000){
	}
	data = SPDR;
	return data;
}

uint8_t os_spi_receive (){
	return os_spi_send(0xFF);
}