#include "os_memory_strategies.h"
#include "os_memory.h"


MemAddr os_Memory_FirstFit(Heap *heap, size_t size){
	size_t used = 0;
	MemAddr start = heap->useStart;
	while(start < heap->useStart + heap->useSize){
		if (os_getMapEntry(heap, start) == 0){
			used++;
			if (used == size)
			{
				return (start - size + 1);
			}
		}
		else
		{
			used = 0;
		}
		start++;
	}
	return 0;
}

MemAddr os_Memory_NextFit(Heap *heap, size_t size){
	size_t used = 0;
	if ((heap->nextStart < heap->useStart + heap->useSize)&&(heap->nextStart >= heap->useStart)){
		MemAddr start = heap->nextStart;
		while (start < heap->useStart + heap->useSize){
			if (os_getMapEntry(heap,start)==0){
				used++;
				if (used == size){
					if (start == heap->useSize + heap->useStart -1){
						heap->nextStart=heap->useStart;
					}else heap->nextStart = start + 1;
					return start - size +1;
				}
			}else used =0;
			start++;
		}
	}
	MemAddr result = os_Memory_FirstFit(heap,size);
	if ((result < heap->useStart + heap->useSize)&&(result >= heap->useStart)){
		if (result + size-1 == heap->useSize + heap->useStart -1){
			heap->nextStart=heap->useStart;
		}else heap->nextStart = result + size;
		return result;
	}
	return 0;
}

MemAddr os_Memory_BestFit(Heap *heap, size_t size){
	size_t used = 0;
	size_t smlest = heap->useSize;
	MemAddr start = heap->useStart;
	MemAddr small = 0;
	while(start < heap->useStart + heap->useSize){
		if (os_getMapEntry(heap, start) == 0){
			used++;
			if (used == size){
				if (start == heap->useStart + heap->useSize - 1){
					return (start - size + 1);
				}
				if (os_getMapEntry(heap, start + 1) != 0){
					return (start - size + 1);
				}
				while (os_getMapEntry(heap, start + 1) == 0 && start+1 < heap->useStart + heap->useSize){
					used++;
					start++;
				}
				if (used <= smlest){
					smlest = used;
					small = start - used +1;
				}
				used = 0;
			}
			start++;
		}else {
			used = 0;
			start++;
		}
	}
	return small;
}

MemAddr os_Memory_WorstFit(Heap *heap, size_t size){
	size_t used = 0;
	size_t rest = 0;
	MemAddr start = heap->useStart;
	MemAddr big = 0;
	while(start < heap->useStart + heap->useSize){
		if (os_getMapEntry(heap, start) == 0){
			used++;
			if (used == size){
				while (os_getMapEntry(heap, start + 1) == 0 && start < heap->useStart + heap->useSize){
					used++;
					start++;
					if (used >= (heap->mapSize + heap->useSize)/2){
						return start-used+1;
					}
				}
				if (used > rest){
					rest = used;
					big =start - used +1;
				}
			}
		}
		else
		{
			used = 0;
		}
		start++;
	}
	return big;
}