#ifndef OS_MEM_DRIVERS_H_
#define OS_MEM_DRIVERS_H_

#include "defines.h"
#include <inttypes.h>

#define intSRAM (&intSRAM__)
#define extSRAM (&extSRAM__)

typedef uint16_t MemAddr;

typedef uint8_t	MemValue;

typedef struct MemDriver{
	uint16_t size;
	uint16_t startAddr;
	void (*init)(void);
	MemValue (*read)(MemAddr);
	void (*write)(MemAddr, MemValue);
} MemDriver;

void writeSRAM_internal (MemAddr addr, MemValue value);
MemValue readSRAM_internal (MemAddr addr);
void initSRAM_internal (void);

void initSRAM_external (void);
MemValue readSRAM_external (MemAddr addr);
void writeSRAM_external (MemAddr addr, MemValue value);

void initMemoryDevices(void);

MemDriver intSRAM__;
MemDriver extSRAM__;

#endif /* OS_MEM_DRIVERS_H_ */