#include "os_mem_drivers.h"
#include "defines.h"
#include "os_scheduler.h"
#include "os_spi.h"
#include "util.h"
#include <avr/io.h>
#include <avr/interrupt.h>

MemDriver intSRAM__ = {
	.init = initSRAM_internal,
	.read = readSRAM_internal,
	.write = writeSRAM_internal,
	.startAddr = 0x100,
	.size = HEAPOFFSET+MAP_SIZE*3,
};

MemDriver extSRAM__ = {
	.init = initSRAM_external,
	.read = readSRAM_external,
	.write = writeSRAM_external,
	.startAddr = 0x0,
	.size = 0xFFFF
};

void initSRAM_internal (void){
}

MemValue readSRAM_internal (MemAddr addr){
	uint8_t *a=(uint8_t*) addr;
	return *a;
}

void writeSRAM_internal (MemAddr addr, MemValue value){
	uint8_t* a = (uint8_t*)addr;
	*a = value;
}

void initSRAM_external (void){
	os_spi_init();
	os_enterCriticalSection();
	PORTB &= 0b11101111;
	os_spi_send(0b00000001);
	os_spi_send(0b00000000);
	PORTB |= 0b00010000;
	os_leaveCriticalSection();
}

MemValue readSRAM_external (MemAddr addr){
	os_enterCriticalSection();
	PORTB &= 0b11101111;
	os_spi_send(0b00000011);
	os_spi_send(0b00000000);
	os_spi_send(addr >> 8);
	os_spi_send(addr & 0x00FF);
	MemValue rd=os_spi_receive();
	PORTB |= 0b00010000;
	os_leaveCriticalSection();
	return rd;
}

void writeSRAM_external (MemAddr addr, MemValue value){
	os_enterCriticalSection();
	PORTB &= 0b11101111;
	os_spi_send(0b00000010);
	os_spi_send(0b00000000);
	os_spi_send(addr >> 8);
	os_spi_send(addr & 0x00FF);
	os_spi_send(value);
	PORTB |= 0b00010000;
	os_leaveCriticalSection();
}

void initMemoryDevices(void){
	initSRAM_internal();
	initSRAM_external();
}