

#ifndef OS_MEMHEAP_DRIVERS_H_
#define OS_MEMHEAP_DRIVERS_H_

#include "os_mem_drivers.h"
#include <stddef.h>

#define intHeap (&intHeap__)
#define extHeap (&extHeap__)


typedef enum {
	OS_MEM_FIRST,
	OS_MEM_NEXT,
	OS_MEM_BEST,
	OS_MEM_WORST
}AllocStrategy;

typedef struct {
	MemDriver *driver;
	uint16_t mapStart;
	uint16_t mapSize;
	uint16_t useStart;
	uint16_t useSize;
	AllocStrategy currentAllocStrategy;
	char *name;
	MemAddr nextStart;
	MemAddr allocFrameStart[MAX_NUMBER_OF_PROCESSES];
	MemAddr allocFrameEnd[MAX_NUMBER_OF_PROCESSES];
}Heap;

Heap intHeap__;
Heap extHeap__;

void os_initHeaps (void);

Heap *os_lookupHeap (uint8_t index);

size_t os_getHeapListLength (void);

#endif /* OS_MEMHEAP_DRIVERS_H_ */