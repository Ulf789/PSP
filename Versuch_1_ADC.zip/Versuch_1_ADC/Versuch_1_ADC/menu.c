#include "menu.h"
#include "os_input.h"
#include "bin_clock.h"
#include "lcd.h"
#include "led.h"
#include "adc.h"
#include <stdint.h>
#include <avr/io.h>
#include <util/delay.h>

/*!
 *  Hello world program.
 *  Shows the string 'Hello World!' on the display.
 */
void helloWorld(void) {
    // Repeat until ESC gets pressed
    //#warning IMPLEMENT STH. HERE
	while (os_getInput() != 0b00001000){
		lcd_writeProgString(PSTR("Hello world !"));
		_delay_ms(500);
		lcd_clear();
		_delay_ms(500);
	}
	os_waitForNoInput();
	showMenu();
}

/*!
 *  Shows the clock on the display and a binary clock on the led bar.
 */
void displayClock(void) {
    //#warning IMPLEMENT STH. HERE
	while (os_getInput() != 0b00001000){
		uint16_t clockVal;
		clockVal = getTimeHours();
		clockVal = clockVal << 6;
		clockVal+= getTimeMinutes();
		clockVal = clockVal << 6;
		clockVal+= getTimeSeconds();
		setLedBar(clockVal);
		if (getTimeHours()<10){
			lcd_writeProgString(PSTR("0"));
			lcd_writeDec(getTimeHours());
		}else lcd_writeDec(getTimeHours());
		lcd_writeProgString(PSTR(":"));
		if (getTimeMinutes()<10){
			lcd_writeProgString(PSTR("0"));
			lcd_writeDec(getTimeMinutes());
		}else lcd_writeDec(getTimeMinutes());
		lcd_writeProgString(PSTR(":"));
		if (getTimeSeconds()<10){
			lcd_writeProgString(PSTR("0"));
			lcd_writeDec(getTimeSeconds());
		}else lcd_writeDec(getTimeSeconds());
		lcd_writeProgString(PSTR(":"));
		if (getTimeMilliseconds()<10){
			lcd_writeProgString(PSTR("00"));
			lcd_writeDec(getTimeMilliseconds());
		}else if (getTimeMilliseconds()<100){
			lcd_writeProgString(PSTR("0"));
			lcd_writeDec(getTimeMilliseconds());
		}else lcd_writeDec(getTimeMilliseconds());
		_delay_ms(100);
		lcd_clear();
	}
	os_waitForNoInput();
	showMenu();
}

/*!
 *  Shows the stored voltage values in the second line of the display.
 */
void displayVoltageBuffer(uint8_t displayIndex) {
    //#warning IMPLEMENT STH. HERE
	if (displayIndex < 9)
	{
		lcd_writeString("0");
	}
	lcd_writeDec(displayIndex+1);
	lcd_writeProgString(PSTR("/100 : "));
	lcd_writeVoltage(getStoredVoltage(displayIndex),1023,5);
}

/*!
 *  Shows the ADC value on the display and on the led bar.
 */
void displayAdc(void) {
    //#warning IMPLEMENT STH. HERE
	uint8_t count = 0 ;
	while (os_getInput() != 0b00001000){
		lcd_writeProgString(PSTR("Voltage:"));
		//lcd_writeDec(getAdcValue());
		lcd_writeVoltage(getAdcValue(),1023,5);
		uint16_t ledValue=0;
		uint16_t adcResult = getAdcValue();
		while (adcResult >= 68){
			ledValue = ledValue*2;
			ledValue += 2;
			adcResult = adcResult-68;
		}
		setLedBar(ledValue);
		if (os_getInput() == 0b00000001 && count < 100){
			storeVoltage();
		}
		lcd_line2();
		//_delay_ms(50);
		displayVoltageBuffer(count);
		if (os_getInput() == 0b00000010 ){
			//os_waitForNoInput();
			if (count > 0)
			{
				count--;
			}else{
				count = getBufferIndex() - 1;
			}
		}
		if (os_getInput() == 0b00000100 ){
			//os_waitForNoInput();
			if (count < getBufferIndex() - 1)
			{
				count++;
			}else{
				count = 0;
			}
		}
		_delay_ms(100);
		lcd_clear();
	}
	os_waitForNoInput();
	showMenu();
}

/*! \brief Starts the passed program
 *
 * \param programIndex Index of the program to start.
 */
void start(uint8_t programIndex) {
    // Initialize and start the passed 'program'
    switch (programIndex) {
        case 0:
            lcd_clear();
            helloWorld();
            break;
        case 1:
            activateLedMask = 0xFFFF; // Use all LEDs
            initLedBar();
            initClock();
            displayClock();
            break;
        case 2:
            activateLedMask = 0xFFFE; // Don't use LED 0
            initLedBar();
            initAdc();
            displayAdc();
            break;
        default:
            break;
    }

    // Do not resume to the menu until all buttons are released
    os_waitForNoInput();
}

/*!
 *  Shows a user menu on the display which allows to start subprograms.
 */
void showMenu(void) {
    uint8_t pageIndex = 0;

    while (1) {
        lcd_clear();
        lcd_writeProgString(PSTR("Select:"));
        lcd_line2();

        switch (pageIndex) {
            case 0:
                lcd_writeProgString(PSTR("1: Hello world"));
                break;
            case 1:
                lcd_writeProgString(PSTR("2: Binary clock"));
                break;
            case 2:
                lcd_writeProgString(PSTR("3: Internal ADC"));
                break;
            default:
                lcd_writeProgString(PSTR("----------------"));
                break;
        }

        os_waitForInput();
        if (os_getInput() == 0b00000001) { // Enter
            os_waitForNoInput();
            start(pageIndex);
        } else if (os_getInput() == 0b00000100) { // Up
            os_waitForNoInput();
            pageIndex = (pageIndex + 1) % 3;
        } else if (os_getInput() == 0b00000010) { // Down
            os_waitForNoInput();
            if (pageIndex == 0) {
                pageIndex = 2;
            } else {
                pageIndex--;
            }
        }
    }
}
