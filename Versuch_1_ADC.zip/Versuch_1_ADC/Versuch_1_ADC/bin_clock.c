#include "bin_clock.h"
#include <avr/io.h>
#include <avr/interrupt.h>

//! Global variables
//#warning IMPLEMENT STH. HERE
uint16_t ms;
uint8_t s;
uint8_t m;
uint8_t h;


/*!
 * \return The milliseconds counter of the current time.
 */
uint16_t getTimeMilliseconds() {
    //#warning IMPLEMENT STH. HERE
	return ms & 0xFFFF;
}

/*!
 * \return The seconds counter of the current time.
 */
uint8_t getTimeSeconds() {
    //#warning IMPLEMENT STH. HERE
	return s & 0xFF;
}

/*!
 * \return The minutes counter of the current time.
 */
uint8_t getTimeMinutes() {
    //#warning IMPLEMENT STH. HERE
	return m & 0xFF;
}

/*!
 * \return The hour counter of the current time.
 */
uint8_t getTimeHours() {
    //#warning IMPLEMENT STH. HERE
	return h & 0xFF;
}

/*!
 *  Initializes the binary clock (ISR and global variables)
 */
void initClock(void) {
    // Set timer mode to CTC
    TCCR0A &= ~(1 << WGM00);
    TCCR0A |= (1 << WGM01);
    TCCR0B &= ~(1 << WGM02);

    // Set prescaler to 1024
    TCCR0B |= (1 << CS02) | (1 << CS00);
    TCCR0B &= ~(1 << CS01);

    // Set compare register to 195 -> match every 10ms
    OCR0A = 195;

    // Init variables
    //#warning IMPLEMENT STH. HERE
	ms = 0;
	s = 0;
	m = 0;
	h = 12;

	

    // Enable timer and global interrupts
    TIMSK0 |= (1 << OCIE0A);
    sei();
}

/*!
 *  Updates the global variables to get a valid 12h-time
 */
void updateClock(void) {
    if (ms==1000){
		s+=1;
		ms=0;
    }
	if (s==60){
		m+=1;
		s=0;
	}
	if (m==60){
		h+=1;
		m=0;
	}
	if (h==13){
		h=1;
	}
}

/*!
 *  ISR to increase second-counter of the clock
 */
ISR(TIMER0_COMPA_vect) {
    //#warning IMPLEMENT STH. HERE
	ms+=10;
	updateClock();
}
