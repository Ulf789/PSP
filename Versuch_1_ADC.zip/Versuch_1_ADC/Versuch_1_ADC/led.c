#include "led.h"
#include <avr/io.h>

uint16_t activateLedMask = 0xFFFF;

/*!
 *  Initializes the led bar. Note: All PORTs will be set to output.
 */
void initLedBar(void) {
    //#warning IMPLEMENT STH. HERE
	DDRA=0xFF & activateLedMask;
	DDRD=0xFF & (activateLedMask >> 8);
	PORTA=0xFF & activateLedMask;
	PORTD=0xFF & (activateLedMask >> 8);
	DDRB=0xFF;
	PORTB=0xFF;
}

/*!
 *  Sets the passed value as states of the led bar (1 = on, 0 = off).
 */
void setLedBar(uint16_t value) {
   //#warning IMPLEMENT STH. HERE
   PORTA = ~(value & 0xFF & activateLedMask);
   PORTD = ~((value & activateLedMask) >> 8);
}
