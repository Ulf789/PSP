#include "os_input.h"

#include <avr/io.h>
#include <stdint.h>

/*! \file
 * Everything that is necessary to get the input from the Buttons in a clean format.
 */


/*!
 *  A simple "Getter"-Function for the Buttons on the evaluation board.\n
 *
 *  \returns The state of the button(s) in the lower bits of the return value.\n
 *  example: 1 Button:  -pushed:   00000001
 *                      -released: 00000000
 *           4 Buttons: 1,3,4 -pushed: 000001101
 *
 */
uint8_t os_getInput(void) {
    //#warning IMPLEMENT STH. HERE
    const uint8_t pressed = ~PINC & 0b00000010 ;
    return pressed >> 1;

}

uint8_t os_getInput2(void) {
	//#warning IMPLEMENT STH. HERE
	const uint8_t pressed = ~PINC & 0b00000001 ;
	return pressed ;

}


/*!
 *  Initializes DDR and PORT for input
 */
void os_initInput() {
    //#warning IMPLEMENT STH. HERE
	DDRD &= 0x0;
	PORTD |= 0xFF;
	DDRA |= 0xFF;
	PORTA|= 0xFF;
	DDRB |= 0xFF;
	PORTB|= 0x00000000;
	DDRC &= 0b11111100;
	PORTC |= 0b00000011;
}

/*!
 *  Endless loop as long as at least one button is pressed.
 */
void os_waitForNoInput() {
    //#warning IMPLEMENT STH. HERE
	while(os_getInput());
}

/*!
 *  Endless loop until at least one button is pressed.
 */
void os_waitForInput() {
    //#warning IMPLEMENT STH. HERE
	while(!os_getInput());
}
