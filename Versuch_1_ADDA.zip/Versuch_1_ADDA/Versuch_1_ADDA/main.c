#include <avr/io.h>
#include <util/delay.h>
#include "os_input.h"


void manuell(void) {
	PORTA = PIND;
	PORTB = ~PIND;
}


uint8_t ref = 0b10000000;


void sar(void) {
	if (os_getInput() == 0b1){
		os_waitForNoInput();
		PORTA =0xff;
		ref = 0b10000000;
		
		PORTB =ref;
		_delay_ms(50);
		while (ref != 0 )
		{
			//PORTB |= ref;
			if (os_getInput2() == 1){
				PORTA &= ~ref;
				ref = ref >> 1;
				PORTB |= ref;
				_delay_ms(50);
			}
			else{
				PORTB ^= ref;
				ref = ref >> 1;
				PORTB |= ref;
				_delay_ms(50);
			}
		}
	}
}

void tracking(void) {
	if(os_getInput() == 0b1){
		os_waitForNoInput();
		//uint8_t ref = 0b10000000;
		while (os_getInput2() == 1 && ref<0xFF){
			ref = ref+1;
			PORTA = ~ref;
			PORTB = ref;
			//ref = ref+1;
			_delay_ms(50);
		}
		while (os_getInput2() == 0 && ref>0){
			PORTA = ~ref;
			PORTB = ref;
			ref = ref-1;
			_delay_ms(50);
		}
	}
}



uint8_t i=1;
int main(void) {
    /* Replace with your application code */
	os_initInput();
	while(1){
		switch(i){
			case 1 : manuell();
			case 2 : tracking();
			case 3 : sar();
		}
	}
}
