/*! \file

Scheduling strategies used by the Interrupt Service RoutineA from Timer 2 (in scheduler.c)
to determine which process may continue its execution next.

The file contains five strategies:
-even
-random
-round-robin
-inactive-aging
-run-to-completion
*/

#include "os_scheduling_strategies.h"
#include "defines.h"

#include <stdlib.h>

/*!
 *  Reset the scheduling information for a specific strategy
 *  This is only relevant for RoundRobin and InactiveAging
 *  and is done when the strategy is changed through os_setSchedulingStrategy
 *
 *  \param strategy  The strategy to reset information for
 */
SchedulingInformation schedulingInfo;

void os_resetSchedulingInformation(SchedulingStrategy strategy) {
	if (strategy == OS_SS_ROUND_ROBIN){
		schedulingInfo.timeSlice = os_getProcessSlot(os_getCurrentProc())->priority;
	}
	if (strategy == OS_SS_INACTIVE_AGING){
		for (uint8_t i=0;i<MAX_NUMBER_OF_PROCESSES;i++)	{
			schedulingInfo.age[i] = 0;
		}
	}
    // This is a presence task
}

/*!
 *  Reset the scheduling information for a specific process slot
 *  This is necessary when a new process is started to clear out any
 *  leftover data from a process that previously occupied that slot
 *
 *  \param id  The process slot to erase state for
 */
void os_resetProcessSchedulingInformation(ProcessID id) {
    // This is a presence task
	schedulingInfo.age[id] = 0;
}

/*!
 *  This function implements the even strategy. Every process gets the same
 *  amount of processing time and is rescheduled after each scheduler call
 *  if there are other processes running other than the idle process.
 *  The idle process is executed if no other process is ready for execution
 *
 *  \param processes An array holding the processes to choose the next process from.
 *  \param current The id of the current process.
 *  \return The next process to be executed determined on the basis of the even strategy.
 */
ProcessID os_Scheduler_Even(Process const processes[], ProcessID current) {
	//#warning IMPLEMENT STH. HERE
	uint8_t next = (current + 1) % MAX_NUMBER_OF_PROCESSES;
	uint8_t flag = 0;
	while (next != current ){
		if (processes[next].state == OS_PS_READY && next != 0){
			flag = 1;
			break;
		}
		next = (next + 1) % MAX_NUMBER_OF_PROCESSES;
	}
	if (flag == 1){
		return next;
	} else if (processes[current].state == OS_PS_READY){
		return current;
	    }else return 0;
}
/*!
 *  This function implements the random strategy. The next process is chosen based on
 *  the result of a pseudo random number generator.
 *
 *  \param processes An array holding the processes to choose the next process from.
 *  \param current The id of the current process.
 *  \return The next process to be executed determined on the basis of the random strategy.
 */
ProcessID os_Scheduler_Random(Process const processes[], ProcessID current) {
    //#warning IMPLEMENT STH. HERE
	uint8_t c = 0;
	uint8_t readyPro[MAX_NUMBER_OF_PROCESSES];
	for (uint8_t i=1; i < MAX_NUMBER_OF_PROCESSES; i++){
		if (processes[i].state == OS_PS_READY){
			readyPro[c] = i;
			c++;
		}
	}
	if (c == 0){
		return 0;
	}else {
		uint16_t count = rand() % c;
		return readyPro[count];
	}
}

/*!
 *  This function implements the round-robin strategy. In this strategy, process priorities
 *  are considered when choosing the next process. A process stays active as long its time slice
 *  does not reach zero. This time slice is initialized with the priority of each specific process
 *  and decremented each time this function is called. If the time slice reaches zero, the even
 *  strategy is used to determine the next process to run.
 *
 *  \param processes An array holding the processes to choose the next process from.
 *  \param current The id of the current process.
 *  \return The next process to be executed determined on the basis of the round robin strategy.
 */

ProcessID os_Scheduler_RoundRobin(Process const processes[], ProcessID current) {
    // This is a presence task
	schedulingInfo.timeSlice--;
	if (schedulingInfo.timeSlice == 0 || processes[current].state != OS_PS_READY){
		ProcessID pid=os_Scheduler_Even(processes,current);
		schedulingInfo.timeSlice = processes[pid].priority;
		return pid;
	}
    return current;
}

/*!
 *  This function realizes the inactive-aging strategy. In this strategy a process specific integer ("the age") is used to determine
 *  which process will be chosen. At first, the age of every waiting process is increased by its priority. After that the oldest
 *  process is chosen. If the oldest process is not distinct, the one with the highest priority is chosen. If this is not distinct
 *  as well, the one with the lower ProcessID is chosen. Before actually returning the ProcessID, the age of the process who
 *  is to be returned is reset to its priority.
 *
 *  \param processes An array holding the processes to choose the next process from.
 *  \param current The id of the current process.
 *  \return The next process to be executed, determined based on the inactive-aging strategy.
 */
ProcessID os_Scheduler_InactiveAging(Process const processes[],ProcessID current) {
	// This is a presence task
	uint8_t oldest = 0;
	for (uint8_t i = 1; i < MAX_NUMBER_OF_PROCESSES; i++) {
		if (i != current && processes[i].state == OS_PS_READY) {
			schedulingInfo.age[i] += processes[i].priority;
			oldest = i;
		}
	}
	for (uint8_t i = 1; i < MAX_NUMBER_OF_PROCESSES; i++) {
		if (processes[i].state == OS_PS_READY) {
			if (schedulingInfo.age[i] > schedulingInfo.age[oldest]) {
				oldest = i;
			}
			if (schedulingInfo.age[i] == schedulingInfo.age[oldest]) {
				if (processes[i].priority == processes[oldest].priority) {
					if (i<oldest){
						oldest = i ;
					}
				} else {
					if (processes[i].priority > processes[oldest].priority){
						oldest = i;
					}
				}
			}
		}
	}
	schedulingInfo.age[oldest] = processes[oldest].priority;
	return oldest;
}
/*!
 *  This function realizes the run-to-completion strategy.
 *  As long as the process that has run before is still ready, it is returned again.
 *  If  it is not ready, the even strategy is used to determine the process to be returned
 *
 *  \param processes An array holding the processes to choose the next process from.
 *  \param current The id of the current process.
 *  \return The next process to be executed, determined based on the run-to-completion strategy.
 */


ProcessID os_Scheduler_RunToCompletion(Process const processes[], ProcessID current) {
    // This is a presence task#
	if(current!=0 && processes[current].state == OS_PS_READY){
		return current;
		}else{
		return os_Scheduler_Even(processes,current);
	}
    return 0;
}
