#include "os_memory.h"
#include "os_memory_strategies.h"
#include "util.h"
#include "os_core.h"

MemValue getLowNibble (Heap const *heap, MemAddr addr){
	return heap->driver->read(addr) & 0b00001111;
}

MemValue getHighNibble (Heap const *heap, MemAddr addr){
	MemValue a = heap->driver->read(addr) & 0b11110000;
	return a >> 4;
}

void setLowNibble (Heap const *heap, MemAddr addr, MemValue value){
	MemValue a = heap->driver->read(addr);
	a &= 0xf0;
	a |= value;
	heap->driver->write(addr,a);
}

void setHighNibble (Heap const *heap, MemAddr addr, MemValue value){
	value = value << 4;
	MemValue a = heap->driver->read(addr);
	a &= 0x0f;
	a |= value;
	heap->driver->write(addr,a);
}

void setMapEntry (Heap const *heap, MemAddr addr, MemValue value){
	if (addr >= heap->useStart && addr < heap->useStart + heap->useSize){
		MemAddr mapAddr = 0;
		if ((addr-heap->useStart)%2 == 1){
			mapAddr = heap->mapStart + (addr - heap->useStart)/2;
			setLowNibble(heap, mapAddr, value);
		}else {
			mapAddr =heap->mapStart + (addr - heap->useStart)/2;
			setHighNibble(heap, mapAddr, value);
		}
	}/*else{
		os_error("addr not in range");
	}*/
}

MemValue os_getMapEntry(Heap const *heap, MemAddr addr){
	os_enterCriticalSection();
	MemAddr m = mapAdrOfuseAdr(heap, addr);
	MemValue a;
	if ((addr - heap->useStart) % 2 == 1){
		a = getLowNibble(heap, m);
		} else{
		a = getHighNibble(heap, m);
	}
	os_leaveCriticalSection();
	return a;
}

MemAddr mapAdrOfuseAdr(Heap const *heap, MemAddr addr){
	addr = addr - heap->useStart;
	addr = addr / 2;
	return heap->mapStart + addr;
}

MemAddr os_malloc(Heap* heap, uint16_t size){
	os_enterCriticalSection();
	if (os_getCurrentProc() == 0){
		os_error("idle");
		os_leaveCriticalSection();
		return 0;
	}
	MemAddr a=0;
	if (heap->currentAllocStrategy == OS_MEM_FIRST){
		a = os_Memory_FirstFit(heap,size);
	}
	if (heap->currentAllocStrategy == OS_MEM_BEST){
		a = os_Memory_BestFit(heap,size);
	}
	if (heap->currentAllocStrategy == OS_MEM_WORST){
		a = os_Memory_WorstFit(heap,size);
	}
	if (heap->currentAllocStrategy == OS_MEM_NEXT){
		a = os_Memory_NextFit(heap,size);
	}
	if (a != 0){
		setMapEntry(heap, a, os_getCurrentProc());
		for (MemAddr i = 1; i < size; i++)
		{
			setMapEntry(heap, a + i, 0xf);
		}
		if ((heap->allocFrameStart[os_getCurrentProc()] == 0) || ( heap->allocFrameStart[os_getCurrentProc()] > a))
		{
			heap->allocFrameStart[os_getCurrentProc()] = a;
		}
		if ((heap->allocFrameEnd[os_getCurrentProc()] == 0) || ( heap->allocFrameEnd[os_getCurrentProc()] < a + size -1))
		{
			heap->allocFrameEnd[os_getCurrentProc()] = a + size -1;
		}
	}
	os_leaveCriticalSection();
	return a;
}


void os_free (Heap *heap, MemAddr addr){
	os_enterCriticalSection();
	MemAddr first = os_getFirstByteOfChunk(heap,addr);
	MemAddr currentSize = os_getChunkSize(heap, addr);
	os_freeOwnerRestricted(heap, addr, os_getCurrentProc());
	if (heap->allocFrameStart[os_getCurrentProc()] == first){
		heap->allocFrameStart[os_getCurrentProc()] = 0;
		for(MemAddr i=first + currentSize;i < heap->useStart + heap->useSize;i++){
			if (os_getMapEntry(heap, i) == os_getCurrentProc()){
				heap->allocFrameStart[os_getCurrentProc()] = i;
				break;
			}
		}
	}
	if (heap->allocFrameEnd[os_getCurrentProc()] == first + currentSize - 1){
		heap->allocFrameEnd[os_getCurrentProc()] = 0;
		for (MemAddr j = first - 1;j >= heap->useStart;j--){
			if (getOwnerOfChunk(heap, j) == os_getCurrentProc()){
				heap->allocFrameEnd[os_getCurrentProc()] = j+ os_getChunkSize(heap,j);
				break;
			}
		}
	}
	os_leaveCriticalSection();
}

void os_freeOwnerRestricted(Heap *heap, MemAddr addr, ProcessID owner){
	os_enterCriticalSection();
	addr = os_getFirstByteOfChunk(heap, addr);
	if (owner == os_getMapEntry(heap, addr) ){
		setMapEntry(heap, addr, 0);
		addr++;
		while (addr < (heap->useStart + heap->useSize) && os_getMapEntry(heap, addr) == 0xF) {
			setMapEntry(heap, addr, 0);
			addr++;
		}
	}
	os_leaveCriticalSection();
}

void os_freeProcessMemory(Heap *heap, ProcessID pid) {
	os_enterCriticalSection();
	for (MemAddr i = heap->allocFrameStart[pid]; i <= heap->allocFrameEnd[pid]; i++){
		if (os_getMapEntry(heap,i)==pid){
			os_freeOwnerRestricted(heap,i,pid);
		}
	}
	os_leaveCriticalSection();
}

MemAddr os_getFirstByteOfChunk(Heap const *heap, MemAddr addr){
	while (os_getMapEntry(heap, addr) == 0xF){
		addr = addr - 1;
	}
	return addr;
}

uint16_t os_getChunkSize(Heap const *heap, MemAddr addr){
	os_enterCriticalSection();
	if (os_getMapEntry(heap,addr)==0){
		os_leaveCriticalSection();
		return 0;
	}
	addr = os_getFirstByteOfChunk(heap,addr);
	MemAddr chunksize = addr;
	chunksize += 1;
	while (os_getMapEntry(heap, chunksize) == 0xF){
		chunksize += 1;
	}
	os_leaveCriticalSection();
	return chunksize - addr;
}

size_t os_getMapSize(Heap const *heap){
	return heap->mapSize;
}

size_t os_getUseSize(Heap const *heap){
	return heap->useSize;
}

MemAddr os_getMapStart(Heap const *heap){
	return heap->mapStart;
}

MemAddr os_getUseStart(Heap const *heap){
	return heap->useStart;
}

AllocStrategy os_getAllocationStrategy(Heap const *heap) {
	return heap->currentAllocStrategy;
}

void os_setAllocationStrategy(Heap *heap, AllocStrategy first) {
	heap->currentAllocStrategy= first;
}

ProcessID getOwnerOfChunk (Heap const *heap, MemAddr addr){
	return os_getMapEntry(heap, os_getFirstByteOfChunk(heap, addr));
}


void moveChunk(Heap *heap, MemAddr oldChunk, size_t oldSize, MemAddr newChunk, size_t newSize){
	if (newSize > oldSize){
		ProcessID master = getOwnerOfChunk(heap,oldChunk);
		for(MemAddr i = 0; i < oldSize; i++) {
			heap->driver->write(newChunk + i, heap->driver->read(oldChunk + i));
		}
		os_free(heap,oldChunk);
		setMapEntry(heap,newChunk,master);
		for(MemAddr i = newChunk + 1; i < newChunk + newSize; i++) {
			setMapEntry(heap, i, 0x0f);
		}
		if (heap->allocFrameStart[master] > newChunk){
			heap->allocFrameStart[master] = newChunk;
		}
		if (heap->allocFrameEnd[master] < newChunk + newSize -1){
			heap->allocFrameEnd[master] = newChunk + newSize -1;
		}
	}
}


MemAddr os_realloc(Heap * heap,MemAddr addr,uint16_t size){
	os_enterCriticalSection();
	MemAddr first = os_getFirstByteOfChunk(heap,addr);
	uint16_t currentSize = os_getChunkSize(heap,first);
	if (size <= currentSize) {
		MemAddr reduce = first + size;
		while(reduce < first + currentSize) {
			setMapEntry(heap ,reduce, 0); 
			reduce++;
		}
		os_leaveCriticalSection();
		return addr;
	}
	
	MemAddr i=0;
	while (os_getMapEntry(heap,first+currentSize-1+i+1) == 0 && first + currentSize-1+i != heap->useStart + heap->useSize-1){
		i++;
		if (i == size-currentSize){
			moveChunk(heap,first,currentSize,first,size);
			os_leaveCriticalSection();
			return first;
			}
	}
	MemAddr j=0;
	while (os_getMapEntry(heap,first-j-1) ==0 && first-j != heap->useStart){
		j++;
	}
	if (j+i >= size-currentSize){
		moveChunk(heap,first,currentSize,first-j,size);
		os_leaveCriticalSection();
		return first-j;
	}

	
	MemAddr new = os_malloc(heap,size);
	if (new != 0){
		moveChunk(heap,first,currentSize,new,size);
		os_leaveCriticalSection();
		return new;
	}else return 0;	
}