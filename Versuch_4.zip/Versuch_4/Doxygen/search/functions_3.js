var searchData=
[
  ['idle_339',['idle',['../os__scheduler_8c.html#a01131b63acf241e9db91704d89ce15d2',1,'os_scheduler.c']]],
  ['initmemorydevices_340',['initMemoryDevices',['../os__mem__drivers_8c.html#a7b4035516f05b473e63dcccfdcbb5ca3',1,'initMemoryDevices(void):&#160;os_mem_drivers.c'],['../os__mem__drivers_8h.html#a7b4035516f05b473e63dcccfdcbb5ca3',1,'initMemoryDevices(void):&#160;os_mem_drivers.c']]],
  ['initsram_5fexternal_341',['initSRAM_external',['../os__mem__drivers_8c.html#ab55b370209e2d049b60ee27982eafd3b',1,'os_mem_drivers.c']]],
  ['initsram_5finternal_342',['initSRAM_internal',['../os__mem__drivers_8c.html#a8826af4dce682bd82546f1efc5ee7874',1,'os_mem_drivers.c']]],
  ['isanyprocready_343',['isAnyProcReady',['../os__scheduling__strategies_8c.html#a0bb20f041ecb373f5b3c6a36ba1e5ecf',1,'os_scheduling_strategies.c']]],
  ['isr_344',['ISR',['../os__scheduler_8c.html#a5686c229bdef50123688ab6cb1404230',1,'ISR(TIMER2_COMPA_vect):&#160;os_scheduler.c'],['../util_8c.html#add2d7cdddfb682dcc0391e60cf42c7d6',1,'ISR(TIMER0_OVF_vect):&#160;util.c']]]
];
