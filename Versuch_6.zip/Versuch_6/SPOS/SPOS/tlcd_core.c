#include <util/delay.h>
#include <stdbool.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

#include "tlcd_core.h"
#include "tlcd_parser.h"
#include "util.h"
#include "os_core.h"

//#warning IMPLEMENT STH. HERE
tlcdBuffer inputBuffer;

/*!
 *  This function configures all relevant ports,
 *  initializes the pin change interrupt, the spi
 *  module and the input buffer
 */

void tlcd_init() {
    //#warning IMPLEMENT STH. HERE
	DDRB |= 0b10111000;
	DDRB &= 0b10111011;
	PORTB |= 0b00010000;
	PORTB |= 0b01000100;
	SPCR |= 0b01010000;//Master aktiv
	SPCR &= 0b01010011;//CP0L CPHA 0 DORD 0 SPIE 0
	SPCR |= 0b00101111;//SPR1 PSR0 1

	tlcd_spi_disable();
	
    // Pin change interrupt on PORTB
    PCICR = (1 << TLCD_SEND_BUFFER_IND_INT_MSK_PORT);
    PCMSK1 = (1 << TLCD_SEND_BUFFER_IND_INT_MSK_PIN);

    // Initial reset
    tlcd_reset();

    // Initialize all buffers
    tlcd_initBuffer();
}


/*!
 *  This function resets the lcd by toggling the reset pin.
 */
void tlcd_reset() {
    //#warning IMPLEMENT STH. HERE
	TLCD_PORT &= 0b11110111;
	_delay_ms(10);
	TLCD_PORT |= 0b00001000;
}

/*!
 *  This function writes a byte to the lcd via SPI
 *  \param byte The byte to be send to the lcd
 */

uint8_t tlcd_writeByte(uint8_t byte) {
    //#warning IMPLEMENT STH. HERE
	//ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    tlcd_spi_enable();
	_delay_us(6);
	SPDR = byte;
	while ((SPSR & 0b10000000) !=0b10000000){
	}
	byte = SPDR;
	tlcd_spi_disable();
	//}
	return byte;
}

/*!
 *  This function waits for a byte to arrive from the lcd and returns it
 *  \returns a byte read from the lcd
 */
uint8_t tlcd_readByte() {
     //#warning IMPLEMENT STH. HERE
     return tlcd_writeByte(0xFF);
}

/*!
 *  This function initializes input buffer
 *  i.e. allocate memory on the internal
 *  heap and initialize head & tail
 */
void tlcd_initBuffer() {
    //#warning IMPLEMENT STH. HERE
	inputBuffer.data = os_malloc(intHeap,INPUTBUFFER_SIZE);
	if (inputBuffer.data == 0){
		os_error("not enough");
		return;
	}
	inputBuffer.size = INPUTBUFFER_SIZE;
	inputBuffer.head = 0;
	inputBuffer.tail = 0;
}

/*!
 *  This function resets the input buffer by setting head & tail to zero
 */
void tlcd_resetBuffer() {
    //#warning IMPLEMENT STH. HERE
	inputBuffer.head = 0;
	inputBuffer.tail = 0;
}

/*!
 *  Writes a given byte into the input buffer and increments the position of head
 *  \param dataByte The byte that is to be stored into the buffer
 */

void tlcd_writeNextBufferElement(uint8_t dataByte) {
    //#warning IMPLEMENT STH. HERE
	if (inputBuffer.head == inputBuffer.size-1){
		inputBuffer.head = (inputBuffer.head + 1)% inputBuffer.size;
	} else inputBuffer.head ++;
	intHeap->driver->write(inputBuffer.data + inputBuffer.head, dataByte);
}
/*!
 *  This function reads a byte from the input buffer and increments the position of tail
 */

uint8_t tlcd_readNextBufferElement() {
    //#warning IMPLEMENT STH. HERE
	uint8_t i = 0;
	if (inputBuffer.head != inputBuffer.tail){
		if (inputBuffer.tail == inputBuffer.size-1){
			inputBuffer.tail = (inputBuffer.tail + 1)% inputBuffer.size;
		} else inputBuffer.tail ++;
		i = intHeap->driver->read(inputBuffer.data + inputBuffer.tail);
	} else os_error("empty buffer");
    return i;
}
/*!
 *  Checks if there are unprocessed data
 */
uint8_t tlcd_hasNextBufferElement() {
    //#warning IMPLEMENT STH. HERE
    if (inputBuffer.head == inputBuffer.tail){
		return 0;
    }else return 1;
}

/*!
 *  This function requests the sending buffer
 *  from the tlcd. Should only be called, if SBUF is low.
 */
void tlcd_requestData() {
    //#warning IMPLEMENT STH. HERE
	//ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
	bool flag = false;
	while (flag == false){
		tlcd_writeByte(DC2_BYTE);
		tlcd_writeByte(0x1);
		tlcd_writeByte(S_BYTE);
		tlcd_writeByte(DC2_BYTE+0x1+S_BYTE);
		if (tlcd_readByte() == ACK){
			flag = true;
		}
	}
	//}
}

/*!
 *  This function reads the complete content of the TLCD sending buffer into the
 *  local input buffer. After a complete frame has been received, the bcc is checked.
 *  In case of a checksum error, the package is ignored by resetting the input buffer
 */

void tlcd_readData() {
    //#warning IMPLEMENT STH. HERE
	if (tlcd_readByte() != DC1_BYTE){
		tlcd_resetBuffer();
		return;
	}
	uint8_t length = tlcd_readByte();
	uint8_t checksum = DC1_BYTE + length;
	uint8_t tempdata[length];
	for (uint8_t i = 0; i < length; i++){
		tempdata[i] = tlcd_readByte();
		checksum += tempdata[i];
	}
	uint8_t bcc = tlcd_readByte();
	if (bcc != checksum){
		tlcd_resetBuffer();
		return;
	}
	for (uint8_t i = 0; i < length; i++) {
		tlcd_writeNextBufferElement(tempdata[i]);
	}
}

/*!
 *  This function sends a command with a given length
 *  \param cmd The cmd to be buffered as a string
 *  \param len The length of the command
 */
void tlcd_sendCommand(const unsigned char* cmd, uint8_t len) {
    //#warning IMPLEMENT STH. HERE
	//ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
	uint8_t quit = NAK;
	while (quit != ACK){
		uint16_t bcc = DC1_BYTE + len;
		tlcd_writeByte(DC1_BYTE);
		tlcd_writeByte(len);
		for(uint8_t i = 0; i < len; i++) {
			tlcd_writeByte(cmd[i]);
			bcc += cmd[i];
		}
		tlcd_writeByte(bcc);
		quit = tlcd_readByte();
	}
	//}
}