#include <avr/interrupt.h>
#include "tlcd_core.h"
#include "tlcd_parser.h"
#include "tlcd_button.h"
#include "util.h"
#include "lcd.h"
#include "os_core.h"
//#warning IMPLEMENT STH. HERE
EventCallback* eventCallback = NULL;
void tlcd_setEventCallback(EventCallback* callback) {
	eventCallback = callback;
}

TouchEvent touchEvent;

/*!
 *  Interrupt Service Routine, which is calls on Pin Change Interrupt.
 *  This ISR handles the incoming data and calls the parsing process.
 */
ISR(PCINT1_vect) {
    //#warning IMPLEMENT STH. HERE
	while ((TLCD_PIN & (1 << PB2))==0) {
		tlcd_requestData();
		tlcd_readData();
		tlcd_parseInputBuffer();
	}
}

/*!
 *  Display a TouchEvent to the Character-LCD.
 *  \param event The TouchEvent to display
 */
void tlcd_displayEvent(TouchEvent event) {
   // #warning IMPLEMENT STH. HERE
   lcd_clear();
   lcd_writeString("( ");
   lcd_writeDec(event.x);
   lcd_writeString(", ");
   lcd_writeDec(event.y);
   lcd_writeString(") ");
   lcd_writeString("Type: ");
   lcd_writeDec(event.type);
}

/*!
 *  This function parses the input buffer content by iterating over
 *  it packet wise and calling the specific parser functions.
 */
void tlcd_parseInputBuffer() {
    //#warning IMPLEMENT STH. HERE
	while (tlcd_hasNextBufferElement()) {
		if (tlcd_readNextBufferElement() == ESC_BYTE){
			if (tlcd_readNextBufferElement() == H_BYTE){
				tlcd_parseTouchEvent();
			}
			else{
				tlcd_parseUnknownEvent();
			}
		}
	}
}

/*!
 *  This function is called when a free touch panel event packet
 *  has been received. The content of the subframe corresponding
 *  to that event is parsed in this function and delegated to the
 *  event handler tlcd_eventHandler(WithCorrection).
 */
void tlcd_parseTouchEvent() {
    //#warning IMPLEMENT STH. HERE
	if (tlcd_readNextBufferElement() != 5){
		os_error("not touchEvent");
	}else{
		touchEvent.type = tlcd_readNextBufferElement();
		touchEvent.x = tlcd_readNextBufferElement() | (tlcd_readNextBufferElement() << 8);
		touchEvent.y = tlcd_readNextBufferElement() | (tlcd_readNextBufferElement() << 8);
		tlcd_displayEvent(touchEvent);
		if (!tlcd_handleButtons(touchEvent)){
			if (eventCallback != NULL) {
				eventCallback(touchEvent);
			}
		}
	}
}


/*!
 *  This function is called when an unknown event packet
 *  has been received and skips the payload by manipulating
 *  the tail of the input buffer.
 */
void tlcd_parseUnknownEvent() {
    //#warning IMPLEMENT STH. HERE
	uint8_t length = tlcd_readNextBufferElement();
	for (uint8_t i = 0; i < length; i++){
		tlcd_readNextBufferElement();
	}
}