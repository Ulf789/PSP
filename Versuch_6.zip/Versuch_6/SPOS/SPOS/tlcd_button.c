#include "tlcd_button.h"
#include "tlcd_graphic.h"
#include "tlcd_parser.h"
#include "os_core.h"
#include "defines.h"
//#warning IMPLEMENT STH. HERE

ButtonCallback* buttonCallback = NULL;

void tlcd_setButtonCallback(ButtonCallback* callback) {
	buttonCallback = callback;
}

Button buttonBuffer[MAX_BUTTONS];
uint8_t buttonId = 0;
/*!
 *  Add a button to the screen and internal logic to be handled by the handleButtons function.
 *  In addition the button will present a character as label.
 *  \param x1 X-coordinate of the starting point
 *  \param y1 Y-coordinate of the starting point
 *  \param x2 X-coordinate of the ending point
 *  \param y2 Y-coordinate of the ending point
 *  \param color The color index of the color the button should be drawn in
 *  \param downCode The code to be send if the button is pressed
 *  \param c The character to display on the button
 */
void tlcd_addButtonWithChar(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint8_t color, uint8_t downCode, char c) {
    //#warning IMPLEMENT STH. HERE
	if (buttonId >= MAX_BUTTONS){
		os_error("full buttons");
	}else {
		buttonBuffer[buttonId].x1 = x1;
		buttonBuffer[buttonId].y1 = y1;
		buttonBuffer[buttonId].x2 = x2;
		buttonBuffer[buttonId].y2 = y2;
		buttonBuffer[buttonId].color = color;
		buttonBuffer[buttonId].downCode = downCode;
		buttonBuffer[buttonId].label = c;
		buttonId++;
	}
};

/*!
 *  Draw the buttons onto the screen.
 *  This function should be called whenever the screen was cleared.
 */
void tlcd_drawButtons() {
    //#warning IMPLEMENT STH. HERE
	for (uint8_t i = 0; i < buttonId; i++) {
		Button button = buttonBuffer[i];
		if (buttonBuffer[i].color != 0) {
			tlcd_drawBox(button.x1, button.y1, button.x2, button.y2, button.color);
		}
		if (buttonBuffer[i].label != ' ') {
			tlcd_drawChar((button.x1 + button.x2)/2, (button.y1 + button.y2)/2, button.label);
		}
	}
}

/*!
 *  Check an event against all buttons for collision and execute button function if a button was pressed.
 *  Will return 1 if the event was inside a button and a 0 otherwise.
 *  \param event The touchevent to handle
 *  \return 1 if event was handled, 0 otherwise
 */
uint8_t tlcd_handleButtons(TouchEvent event) {
    //#warning IMPLEMENT STH. HERE
	    uint8_t isHandled = 0;
	    uint16_t x = event.x;
	    uint16_t y = event.y;
	    for (uint8_t i = 0; i < buttonId; i++) {
		    Button button = buttonBuffer[i];
		    if (x >= button.x1 && x <= button.x2 && y >= button.y1 && y <= button.y2) {
			    if (event.type == TOUCHPANEL_DOWN) {
				    if (buttonCallback != NULL) {
					    buttonCallback(button.downCode, x, y);
				    }
			    }
			    isHandled = 1;
			    break;
		    }
	    }
	    return isHandled;
}