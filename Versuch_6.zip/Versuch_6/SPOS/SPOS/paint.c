#include <avr/pgmspace.h>
#include <util/atomic.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdint.h>
#include <string.h>
#include "tlcd_core.h"
#include "lcd.h"
#include "util.h"
#include "os_input.h"
#include "os_core.h"
#include "tlcd_graphic.h"
#include "tlcd_parser.h"
#include "tlcd_button.h"
#include "defines.h"
#include "paint.h"

/*
#define BACKGROUND_COLOR 16
void initializePaint(void);
void handleButtonPress(uint8_t code, uint16_t x, uint16_t y);
void handleTouchEvent(TouchEvent event);
void defineColors2(void);
void drawRainbow();
uint8_t getRainbowColor(uint16_t x);
*/


uint8_t penSize = 5;
uint8_t penColor = 14;
uint8_t isEraserMode = 0;
TouchEvent prevEvent;

void initializePaint() {
	tlcd_init();
	tlcd_defineTouchArea(0, 0, TLCD_WIDTH, TLCD_HEIGHT);
	tlcd_clearDisplay();
	defineColors2();
	tlcd_addButtonWithChar(430, 150, 470, 190, 15, PENSIZE_INCREASE, '+');
	tlcd_addButtonWithChar(430, 100, 470, 140, 15, PENSIZE_DECREASE, '-');
	tlcd_addButtonWithChar(430, 50, 470, 90, 15, ERASER, 'E');
	tlcd_addButtonWithChar(0, 220, 470, 270, 16, 36, ' ');
	tlcd_setButtonCallback(handleButtonPress);
	tlcd_setEventCallback(handleTouchEvent);
	tlcd_drawButtons();
	drawRainbow();
	tlcd_changePenSize(penSize);
	tlcd_changeDrawColor(penColor);
}

void handleButtonPress(uint8_t code, uint16_t x, uint16_t y) {
	if (code == PENSIZE_INCREASE) {
		penSize += 1;
		if (penSize > 15) {
			penSize = 15;
		}
		tlcd_changePenSize(penSize);
	}
	if (code == PENSIZE_DECREASE) {
		penSize -= 1;
		if (penSize < 1) {
			penSize = 1;
		}
		tlcd_changePenSize(penSize);
	}
	if (code == ERASER) {
		if (!isEraserMode){
			isEraserMode = 1;
			tlcd_changeDrawColor(BACKGROUND_COLOR);
			tlcd_changePenSize(15);
		}
		else
		{
			isEraserMode = 0;
			tlcd_changeDrawColor(penColor);
			tlcd_changePenSize(penSize);
		}
	}
	if (code == 36) {
		uint8_t colorID = getRainbowColor(x);
		penColor = colorID;
		tlcd_changeDrawColor(colorID);
	}
}

void handleTouchEvent(TouchEvent event) {
	if (event.x > 429 || event.y > 219){
		return;
		}else{
		if (event.type == TOUCHPANEL_DRAG){
			if (prevEvent.type == TOUCHPANEL_DRAG || prevEvent.type == TOUCHPANEL_DOWN){
				tlcd_drawLine(prevEvent.x, prevEvent.y, event.x, event.y);
			}
			prevEvent = event;
			}else{
			prevEvent = event;
			if (event.type == TOUCHPANEL_DOWN) {
				uint16_t x = event.x;
				uint16_t y = event.y;
				tlcd_drawPoint(x, y);
			}
		}
	}
}

void defineColors2() {
	unsigned char white[] = {0x1B, 0x46, 0x50, 14, 255, 255, 255};
	tlcd_sendCommand(white, 7);
	
	unsigned char grey[] = {0x1B, 0x46, 0x50, 15, 175, 175, 175};
	tlcd_sendCommand(grey, 7);
	
	unsigned char black[] = {0x1B, 0x46, 0x50, 16, 0, 0, 0};
	tlcd_sendCommand(black, 7);
}

void drawRainbow() {
	uint16_t startY = 230;
	uint16_t endY = 270;
	for (uint16_t i = 0; i < 78; i++) {
		uint8_t red = 255;
		uint8_t green = i * (255/78);
		uint8_t blue = 0;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
	for (uint16_t i = 78; i < 156; i++){
		uint8_t red = (156- i) * (255/78);
		uint8_t green = 255;
		uint8_t blue = 0;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
	for (uint16_t i =156;i < 234; i++){
		uint8_t red = 0;
		uint8_t green = 255;
		uint8_t blue = (i - 156) * (255/78);
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
	for (uint16_t i=234; i < 312; i++){
		uint8_t red = 0;
		uint8_t green = (312- i) * (255/78);
		uint8_t blue = 255;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
	for (uint16_t i =312; i < 390 ; i++){
		uint8_t red = (i - 312) * (255/78);
		uint8_t green = 0;
		uint8_t blue = 255;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
	for (uint16_t i=390; i < 470; i++){
		uint8_t red = 255;
		uint8_t green = 0;
		uint8_t blue = (470- i) * (255/78);
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
		tlcd_changeDrawColor(1);
		tlcd_drawLine(i, startY, i, endY);
	}
}

uint8_t getRainbowColor(uint16_t x) {
	if (x < 78){
		uint8_t red = 255;
		uint8_t green = x * (255/78);
		uint8_t blue = 0;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	if (x < 156 && x >= 78){
		uint8_t red = (156- x) * (255/78);
		uint8_t green = 255;
		uint8_t blue = 0;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	if (x < 234 && x >= 156){
		uint8_t red = 0;
		uint8_t green = 255;
		uint8_t blue = (x - 156) * (255/78);
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	if (x < 312 && x >= 234){
		uint8_t red = 0;
		uint8_t green = (312- x) * (255/78);
		uint8_t blue = 255;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	if (x < 390 && x >= 312){
		uint8_t red = (x - 312) * (255/78);
		uint8_t green = 0;
		uint8_t blue = 255;
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	if (x < 470 && x >= 390){
		uint8_t red = 255;
		uint8_t green = 0;
		uint8_t blue = (470- x) * (255/78);
		unsigned char color[] = {0x1B, 0x46, 0x50, 1, red, green, blue};
		tlcd_sendCommand(color, 7);
	}
	return 1;
}
