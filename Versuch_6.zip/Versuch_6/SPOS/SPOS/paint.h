#include <avr/pgmspace.h>
#include <util/atomic.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdint.h>
#include <string.h>
#include "tlcd_core.h"
#include "lcd.h"
#include "util.h"
#include "os_input.h"
#include "os_core.h"
#include "tlcd_graphic.h"
#include "tlcd_parser.h"
#include "tlcd_button.h"
#include "defines.h"
#define BACKGROUND_COLOR 16

void initializePaint(void);
void handleButtonPress(uint8_t code, uint16_t x, uint16_t y);
void handleTouchEvent(TouchEvent event);
void defineColors2(void);
void drawRainbow();
uint8_t getRainbowColor(uint16_t x);