


#ifndef OS_MEMORY_STRATEGIES_H_
#define OS_MEMORY_STRATEGIES_H_

#include "os_memheap_drivers.h"

MemAddr os_Memory_FirstFit (Heap *heap, size_t size);



#endif /* OS_MEMORY_STRATEGIES_H_ */