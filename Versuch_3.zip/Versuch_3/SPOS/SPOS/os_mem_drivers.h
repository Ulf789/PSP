#ifndef OS_MEM_DRIVERS_H_
#define OS_MEM_DRIVERS_H_

#include "defines.h"
#include <inttypes.h>

#define intSRAM (&intSRAM__)

typedef uint16_t MemAddr;

typedef uint8_t	MemValue;

typedef struct MemDriver{
	uint16_t size;
	uint16_t startAddr;
	void (*init)(void);
	MemValue (*read)(MemAddr);
	void (*write)(MemAddr, MemValue);
} MemDriver;

void writeSRAM_internal (MemAddr addr, MemValue value);
MemValue readSRAM_internal (MemAddr addr);
void initSRAM_internal (void);

MemDriver intSRAM__;

#endif /* OS_MEM_DRIVERS_H_ */