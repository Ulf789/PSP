#include "os_memory.h"
#include "os_memory_strategies.h"
#include "util.h"
#include "os_core.h"

MemValue getLowNibble (Heap const *heap, MemAddr addr){
	return heap->driver->read(addr) & 0b00001111;
}

MemValue getHighNibble (Heap const *heap, MemAddr addr){
	MemValue a = heap->driver->read(addr) & 0b11110000;
	return a >> 4;
}

void setLowNibble (Heap const *heap, MemAddr addr, MemValue value){
	MemValue a = heap->driver->read(addr);
	a &= 0xf0;
	a |= value;
	heap->driver->write(addr,a);
}

void setHighNibble (Heap const *heap, MemAddr addr, MemValue value){
	value = value << 4;
	MemValue a = heap->driver->read(addr);
	a &= 0x0f;
	a |= value;
	heap->driver->write(addr,a);
}

void setMapEntry (Heap const *heap, MemAddr addr, MemValue value){
	if (addr >= heap->useStart && addr < heap->useStart + heap->useSize){
		MemAddr mapAddr = 0;
		if ((addr-heap->useStart)%2 == 1){
			mapAddr = heap->mapStart + (addr - heap->useStart)/2;
			setLowNibble(heap, mapAddr, value);
		}else {
			mapAddr =heap->mapStart + (addr - heap->useStart)/2;
			setHighNibble(heap, mapAddr, value);
		}
	}else{
		os_error("addr not in range");
	}
}

MemValue os_getMapEntry(Heap const *heap, MemAddr addr){
	os_enterCriticalSection();
	MemAddr m = mapAdrOfuseAdr(heap, addr);
	MemValue a;
	if ((addr - heap->useStart) % 2 == 1){
		a = getLowNibble(heap, m);
		} else{
		a = getHighNibble(heap, m);
	}
	os_leaveCriticalSection();
	return a;
}

MemAddr mapAdrOfuseAdr(Heap const *heap, MemAddr addr){
	addr = addr - heap->useStart;
	addr = addr / 2;
	return heap->mapStart + addr;
}

MemAddr os_malloc(Heap* heap, uint16_t size){
	os_enterCriticalSection();
	if (os_getCurrentProc() == 0){
		os_error("idle");
		os_leaveCriticalSection();
		return 0;
	}
	MemAddr a=0;
	if (os_Memory_FirstFit(heap,size) != 0){
		a = os_Memory_FirstFit(heap,size);
		setMapEntry(heap, a, os_getCurrentProc());
		for (MemAddr i = 1; i < size; i++)
		{
			setMapEntry(heap, a + i, 0xf);
		}
	}
	os_leaveCriticalSection();
	return a;
}

void os_free(Heap *heap, MemAddr addr){
	os_enterCriticalSection();
	os_freeOwnerRestricted(heap, addr, os_getCurrentProc());
	os_leaveCriticalSection();
}

void os_freeOwnerRestricted(Heap *heap, MemAddr addr, ProcessID owner){
	os_enterCriticalSection();
	while (os_getMapEntry(heap, addr) == 0xF){
		addr = addr - 1;
	}
	addr = os_getFirstByteOfChunk(heap, addr);
	if (owner == os_getMapEntry(heap, addr) ){
		setMapEntry(heap, addr, 0);
		addr++;
		while (addr < (heap->useStart + heap->useSize) && os_getMapEntry(heap, addr) == 0xF) {
			setMapEntry(heap, addr, 0);
			addr++;
		}
	}
	os_leaveCriticalSection();
}

MemAddr os_getFirstByteOfChunk(Heap const *heap, MemAddr addr){
	while (os_getMapEntry(heap, addr) == 0xF){
		addr = addr - 1;
	}
	return addr;
}

uint16_t os_getChunkSize(Heap const *heap, MemAddr addr){
	os_enterCriticalSection();
	if (os_getMapEntry(heap,addr)==0){
		os_leaveCriticalSection();
		return 0;
	}
	addr = os_getFirstByteOfChunk(heap,addr);
	MemAddr chunksize = addr;
	chunksize += 1;
	while (os_getMapEntry(heap, chunksize) == 0xF){
		chunksize += 1;
	}
	os_leaveCriticalSection();
	return chunksize - addr;
}

size_t os_getMapSize(Heap const *heap){
	return heap->mapSize;
}

size_t os_getUseSize(Heap const *heap){
	return heap->useSize;
}

MemAddr os_getMapStart(Heap const *heap){
	return heap->mapStart;
}

MemAddr os_getUseStart(Heap const *heap){
	return heap->useStart;
}

AllocStrategy os_getAllocationStrategy(Heap const *heap) {
	return heap->currentAllocStrategy;
}

void os_setAllocationStrategy(Heap *heap, AllocStrategy first) {
	heap->currentAllocStrategy= first;
}