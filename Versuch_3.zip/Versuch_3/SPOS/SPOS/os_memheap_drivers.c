#include "os_memheap_drivers.h"
#include "defines.h"
#include "os_memory_strategies.h"
#include <avr/pgmspace.h>

char intStr[] = "internal";


Heap intHeap__ = {
	.driver = intSRAM,
	.mapStart = HEAPBOTTOM,
	.mapSize = MAP_SIZE,
	.useStart = HEAPBOTTOM + MAP_SIZE,
	.useSize = MAP_SIZE+MAP_SIZE,
	.currentAllocStrategy = OS_MEM_FIRST,
	.name = intStr,
};

void os_initHeaps(){
	for (uint16_t i=0;i<intHeap__.mapSize;i++){
		intHeap__.driver->write(intHeap__.mapStart+i, 0);
	}
}

size_t os_getHeapListLength (void){
	return 1;
}

Heap *os_lookupHeap (uint8_t index){
	if (index == 0){
		return intHeap;
	}
	return intHeap;
}