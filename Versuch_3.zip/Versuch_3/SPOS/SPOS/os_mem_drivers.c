#include "os_mem_drivers.h"
#include "defines.h"

MemDriver intSRAM__ = {
	.init = initSRAM_internal,
	.read = readSRAM_internal,
	.write = writeSRAM_internal,
	.startAddr = 0x100,
	.size = HEAPOFFSET+MAP_SIZE*3,
};

void initSRAM_internal (void){
}

MemValue readSRAM_internal (MemAddr addr){
	uint8_t *a=(uint8_t*) addr;
	return *a;
}

void writeSRAM_internal (MemAddr addr, MemValue value){
	uint8_t* a = (uint8_t*)addr;
	*a = value;
}
