#include "os_memory_strategies.h"
#include "os_memory.h"

MemAddr os_Memory_FirstFit(Heap *heap, size_t size){
	size_t used = 0;
	MemAddr start = heap->useStart;
	while(start < heap->useStart + heap->useSize){
		if (os_getMapEntry(heap, start) == 0){
			used++;
			if (used == size)
			{
				return (start - size + 1);
			}
		}
		else
		{
			used = 0;
		}
		start++;
	}
	return 0;
}